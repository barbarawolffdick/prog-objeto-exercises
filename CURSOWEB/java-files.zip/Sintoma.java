public class Sintoma{
private String nome;
private int duracao;

  public Sintoma( ){
    nome=""; duracao=0;
  }
  public void setNome(String snome){
    nome=snome;
  }
  public void setDuracao(int iduracao){
    duracao=iduracao;
  }

  public String getNome()
  {
  return nome; }

  public int getDuracao()
  {
  return duracao; }

}
