public class Doenca{
private String nome, sintoma;

  public Doenca( ){
    nome=""; sintoma="";
  }
  public void setNome(String snome){
    nome=snome;
  }
  public void setSintoma(String ssintoma){
    sintoma=ssintoma;
  }

  public String getNome()
  {
  return nome; }

  public String getSintoma()
  {
  return sintoma; }

}
