
public class Medico{
private String nome, especiali;

  public Medico( ){
    nome=""; especiali="";
  }
  public void setNome(String snome){
    nome=snome;
  }
  public void setEspeciali(String sespeciali){
    especiali=sespeciali;
  }

  public String getNome()
  {
  return nome; }

  public String getEspeciali()
  {
  return especiali; }

}
